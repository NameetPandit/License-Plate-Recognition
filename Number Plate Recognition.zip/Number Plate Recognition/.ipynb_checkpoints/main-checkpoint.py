from fastapi import FastAPI, File, UploadFile, Form
from fastapi.staticfiles import StaticFiles
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
import shutil
import easyocr
import mysql.connector
from mysql.connector import Error
import uvicorn
import re
from ocr_module import save_image,process_license_plate

app = FastAPI()
# Mount the static folder to serve HTML, CSS, and JS
app.mount("/static", StaticFiles(directory="static"), name="static")


# Initialize EasyOCR Reader
reader = easyocr.Reader(["en"])

# MySQL Database Connection
def connect_db():
    try:
        conn = mysql.connector.connect(
            host="localhost",
            user="root",
            password="root",
            database="vehicle_access"
        )
        return conn
    except Error as e:
        print(f"Error: {e}")
        return None

# Directory to save uploaded images
UPLOAD_DIR = "uploaded_images"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# Endpoint to check if API is running
@app.get("/")
def home():
    return {"message": "Vehicle Access Control API is Running!"}

# Image Upload Endpoint
@app.post("/upload_image")
async def upload_image(file: UploadFile = File(...)):
    file_path = f"{UPLOAD_DIR}/{file.filename}"
    
    # Save file
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    # OCR Processing
    #result = reader.readtext(file_path)
    #extracted_text = "".join([res[1] for res in result])
    #extracted_text = re.sub(r"\.","",extracted_text)
    plate_number = process_license_plate(file_path)

    return {"license_plate": plate_number}

# Store Plate Number in Database
@app.post("/store_plate")
def store_plate(plate_number: str = Form(...), owner_name: str = Form(...)):
    conn = connect_db()
    if conn is None:
        return {"error": "Database connection failed"}
    
    try:
        cursor = conn.cursor()
        query = "INSERT INTO license_plates (plate_number, owner_name) VALUES (%s, %s)"
        cursor.execute(query, (plate_number, owner_name))
        conn.commit()
        return {"message": "Data stored successfully"}
    except Error as e:
        return {"error": str(e)}
    finally:
        cursor.close()
        conn.close()

# Run the FastAPI Server
if __name__ == "__main__":
    uvicorn.run(app, host="127.0.0.1", port=5000, reload=True)
