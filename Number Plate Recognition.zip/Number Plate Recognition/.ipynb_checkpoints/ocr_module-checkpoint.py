import easyocr
import os
import re
import cv2
import numpy as np

# Initialize EasyOCR Reader
reader = easyocr.Reader(["en"])

# Directory to store uploaded images
UPLOAD_DIR = "uploaded_images"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def save_image(file):
    """
    Saves the uploaded image to the UPLOAD_DIR and returns the file path.
    """
    file_path = os.path.join(UPLOAD_DIR, file.filename)
    
    with open(file_path, "wb") as buffer:
        buffer.write(file.file.read())
    
    return file_path

def preprocess_image(image_path):
    """
    Reads and preprocesses the image to improve OCR accuracy.
    - Converts to grayscale
    - Applies Gaussian blur
    - Uses adaptive thresholding
    """
    img = cv2.imread(image_path)

    if img is None:
        print("Error: Unable to read image.")
        return None

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # Convert to grayscale
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)  # Apply Gaussian blur
    thresh = cv2.adaptiveThreshold(
        blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2
    )  # Apply adaptive thresholding

    # Save preprocessed image for debugging
    preprocessed_path = image_path.replace(".jpg", "_processed.jpg")
    cv2.imwrite(preprocessed_path, thresh)

    return preprocessed_path

def process_license_plate(image_path):
    """
    Processes the license plate from an image and extracts text using EasyOCR.
    """
    preprocessed_path = preprocess_image(image_path)
    
    if not preprocessed_path:
        return "Preprocessing failed"

    result = reader.readtext(preprocessed_path)
    
    print("OCR Raw Output:", result)  # Debugging output

    if not result:
        return "No text detected"

    # Extract text from OCR result
    extracted_text = "".join([res[1] for res in result])

    # Remove special characters (dots, spaces, etc.)
    extracted_text = re.sub(r"[^A-Za-z0-9]", "", extracted_text)

    print("Final Processed Plate:", extracted_text)  # Debugging output

    return extracted_text
